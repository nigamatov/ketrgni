let min = 30;

if (min >= 0 && min <= 14) {
    console.log('Число попадает в первую четверть часа');
} else if (min >= 15 && min <= 29) {
    console.log('Число попадает во вторую четверть часа');
} else if (min >= 30 && min <= 44) {
    console.log('Число попадает в третью четверть часа');
} else if (min >= 45 && min <= 59) {
    console.log('Число попадает в четвертую четверть часа');
} else {
    console.log('Введено некорректное значение');
}





let lang = 'ru'; 
let arr;

switch (lang) {
    case 'ru':
        arr = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье'];
        break;
    case 'en':
        arr = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        break;
    default:
        arr = 'Некорректный язык';
}

console.log(arr);

let lang = 'ru';
let arr = [
    ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье'],
    ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
];

console.log(arr[lang === 'ru' ? 0 : 1]);




let a = 5; 

if (a > 0 && a < 5) {
    console.log('Верно');
} else {
    console.log('Неверно');
}
a = 5;
console.log(a);

a = 0;
console.log(a); 

a = -3;
console.log(a); 

a = 2;
console.log(a); 

2

let a = 5;

if (a === 0 || a === 2) {
    a += 7;
} else {
    a /= 10;
}

console.log(a);


a = 5;
console.log(a);

a = 0;
console.log(a);

a = -3;
console.log(a);

a = 2;
console.log(a);

3


let a = 1; 
let b = 3; 

if (a <= 1 && b >= 3) {
    console.log(a + b);
} else {
    console.log(a - b);
}
a = 1;
b = 3;
console.log(a + b);

a = 0;
b = 6;
console.log(a - b); 

a = 3;
b = 5;
console.log(a - b);


4

let a = 5;
let b = 8;

if (a > 2 && a < 11 || b >= 6 && b < 14) {
    console.log('Верно');
} else {
    console.log('Неверно');
}

a = 5;
b = 8;
console.log(a + b);

a = 0;
b = 0;
console.log(a + b);

a = -3;
b = -3;
console.log(a + b);

a = 2;
b = 2;
console.log(a + b); 



num = 1;
let result;

switch (num) {
    case 1:
        result = 'зима';
        break;
    case 2:
        result = 'весна';
        break;
    case 3:
        result = 'лето';
        break;
    case 4:
        result = 'осень';
        break;
    default:
        result = 'Некорректное значение';
}

console.log(result);

num = 1;
console.log(num);

num = 2;
console.log(num);

num = 3;
console.log(num);

num = 4;
console.log(num);

Задачи



let day = 15; 
let decade;

if (day >= 1 && day <= 10) {
    decade = 'первая декада';
} else if (day >= 11 && day <= 20) {
    decade = 'вторая декада';
} else if (day >= 21 && day <= 31) {
    decade = 'третья декада';
} else {
    decade = 'Некорректное значение';
}

console.log(`Число ${day} попадает в ${decade} декаду месяца`);
day = 1;
console.log(day);

day = 10;
console.log(day);

day = 20;
console.log(day);

day = 31;
console.log(day);



let month = 3; 
let season;

if (month === 12 || month >= 1 && month <= 2) {
    season = 'зима';
} else if (month >= 3 && month <= 5) {
    season = 'весна';
} else if (month >= 6 && month <= 8) {
    season = 'лето';
} else if (month >= 9 && month <= 11) {
    season = 'осень';
} else {
    season = 'Некорректное значение';
}

console.log(`Месяц ${month} попадает в ${season} пору года`);
month = 1;
console.log(month);

month = 3;
console.log(month); 

month = 6;
console.log(month); 

month = 9;
console.log(month);

month = 12;
console.log(month); 




let str = 'abcde';

if (str.charAt(0) === 'a') {
    console.log('да');
} else {
    console.log('нет');
}
str = 'abcde';
console.log(str); 

str = 'abc';
console.log(str);

str = 'a';
console.log(str);

str = 'b';
console.log(str); 




let str = '12345'; 

if (str.charAt(0) === '1' || str.charAt(0) === '2' || str.charAt(0) === '3') {
    console.log('да');
} else {
    console.log('нет');
}
str = '12345';
console.log(str);

str = '23456';
console.log(str); 

str = '34567';
console.log(str); 

str = '45678';
console.log(str);



let str = '123';
let sum = Number(str.charAt(0)) + Number(str.charAt(1)) + Number(str.charAt(2));

console.log(sum);
str = '123';
console.log(str);

str = '456';
console.log(str);

str = '789';
console.log(str); 



let str = '123456';
let sum1 = Number(str.charAt(0)) + Number(str.charAt(1)) + Number(str.charAt(2));
let sum2 = Number(str.charAt(3)) + Number(str.charAt(4)) + Number(str.charAt(5));

if (sum1 === sum2) {
    console.log('да');
} else {
    console.log('нет');
}
str = '123456';
console.log(str); 

str = '112233';
console.log(str); 

str = '1234567';
console.log(str); 


























